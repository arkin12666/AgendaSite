<?php
    $titulo = filter_input(INPUT_POST, "titulo", FILTER_SANITIZE_SPECIAL_CHARS);
    $descricao = filter_input(INPUT_POST, "descricao", FILTER_SANITIZE_SPECIAL_CHARS);
    $data = filter_input(INPUT_POST, "dia", FILTER_SANITIZE_SPECIAL_CHARS);
    $hora = filter_input(INPUT_POST, "hora", FILTER_SANITIZE_SPECIAL_CHARS);

    try{
        require_once ("./conexao/conexao.php");

        $comandoSQL = "INSERT INTO alarme
                        (tituloAlarme,
                        descricaoAlarme,
                        dataAlarme,
                        horaAlarme)
                    VALUES
                        (:titulo,
                        :descricao,
                        :data,
                        :hora)";
        $comando = $conexao->prepare($comandoSQL);

        $comando->execute(array(
            ":titulo" => $titulo,
            ":descricao" => $descricao,
            ":data" => $data,
            ":hora" => $hora
        ));

        if($comando->rowCount() > 0){
                echo "Cadastro realizado com sucesso";
                header("Location: Menu.php"); // Redireciona para Menu.php após o sucesso
                exit();
            }else{
                echo "Cadastro não realizado"; // Ponto e vírgula adicionado
            }
                        
    } catch(PDOException $erro){
        echo "Entre em contato com o suporte: " . $erro->getMessage();
    }
?>