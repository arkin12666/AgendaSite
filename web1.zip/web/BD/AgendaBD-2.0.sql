-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 21/10/2025 às 22:01
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `agendabd`
--
CREATE DATABASE IF NOT EXISTS `agendabd` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `agendabd`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `alarme`
--

CREATE TABLE `alarme` (
  `IDAlarme` int(11) NOT NULL,
  `tituloAlarme` varchar(50) NOT NULL,
  `descricaoAlarme` varchar(200) DEFAULT NULL,
  `dataAlarme` date NOT NULL,
  `horaAlarme` time NOT NULL,
  `audioAlarme` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `alarme`
--

INSERT INTO `alarme` (`IDAlarme`, `tituloAlarme`, `descricaoAlarme`, `dataAlarme`, `horaAlarme`, `audioAlarme`) VALUES
(1, 'testando aí2', 'tomara que funfas agora', '2025-10-21', '16:37:00', NULL),
(2, 'testando aí3', 'funfas', '2025-10-21', '16:51:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `IDUser` int(11) NOT NULL,
  `nomeUser` varchar(80) NOT NULL,
  `emailUser` varchar(255) NOT NULL,
  `senhaUser` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`IDUser`, `nomeUser`, `emailUser`, `senhaUser`) VALUES
(1, 'Vai_se_fuder_Rafael', '', '$2y$10$G'),
(2, 'VAISEFUDERRAFAEL2(A senha é:123123)', '', '$2y$10$Z'),
(3, 'VAISEFUDERRAFAEL2(A senha é:123123)2', '', '$2y$10$36d3fIasI80xHm9KcVeOXeDsvi/6a4VehNbjXARG2/Bs3xBdXDdky'),
(4, 'VAISEFUDERRAFAEL2(A senha é:123123)3', '', '$2y$10$BtMRas2laGdvUUlngIgl9.1Vz838ayKZKSnSozvt7ITOdZ806JDIG');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `alarme`
--
ALTER TABLE `alarme`
  ADD PRIMARY KEY (`IDAlarme`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`IDUser`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `alarme`
--
ALTER TABLE `alarme`
  MODIFY `IDAlarme` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `IDUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
