<?php
  require_once("./_sessao.php")
?>

<!DOCTYPE html>
<html>
<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
 
  <base href="$FLUTTER_BASE_HREF">

  <meta charset="UTF-8">
  <meta content="IE=Edge" http-equiv="X-UA-Compatible">
  <meta name="description" content="A new Flutter project.">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-title" content="agendaweb">
  <link rel="apple-touch-icon" href="icons/Icon-192.png">
  <link rel="icon" type="image/png" href="favicon.png"/>
  <title>AGENDA - CRIAÇÃO</title>
  <link rel="manifest" href="manifest.json">
  <link rel="stylesheet" href="CSS-LOGIN.css">
</head>
<body>
  <div class="container">
    <form action="LOGIN-CRIACAOBD.php" method="post">
      <div class="tela">
        <h1>CADASTRAR CONTA</h1>
        <div class="menu">
          <div class="TextBoxs">
            <input type="text" name="nome" id="nome" placeholder="Digite seu Nome" required>
            <input type="text" name="email" id="email" placeholder="Digite seu Email" required>
            <input type="password" name="senha" id="senha" placeholder="Digite sua Senha" required>
          </div>

          <div class="conteudo">
            <div>
              <button type="submit" class="botoes">CADASTRAR</button>
            </div>

            <div class="outros">
            <h5><a href="LOGIN-PRINCIPAL.php">Voltar</a></h5>
          </div>
        </div>   
      </div>
    </form>
  </div>
  <script src="flutter_bootstrap.js" async></script>
</body>
</html>