<?php
    // echo "<pre>"; // Comentado para não exibir informações de debug em produção
    //     print_r($_POST);
    // echo "</pre>";
    // exit(); // Removido para permitir a execução do código de inserção

    $nome = filter_input(INPUT_POST, "nome", FILTER_SANITIZE_SPECIAL_CHARS); // Corrigido
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_SPECIAL_CHARS);
    $senha = filter_input(INPUT_POST, "senha", FILTER_SANITIZE_SPECIAL_CHARS); // Corrigido

    try {
        require_once("./conexao/conexao.php"); // Caminho corrigido para a pasta Conexao

        $comandoSQL = "INSERT INTO usuario
                        (nomeUser,
                        emailUser,
                        senhaUser)
                    VALUES
                        (:nome,
                        :email,
                        :senha)";

        $comando = $conexao->prepare($comandoSQL);

        $comando->execute(array(
            ":nome"  => $nome,
            ":email" => $email,
            ":senha" => password_hash($senha, PASSWORD_DEFAULT)
        ));

        if($comando->rowCount() > 0){
            echo "Cadastro realizado com sucesso";
            header("Location: Login-Principal.php"); // Redireciona para Menu.php após o sucesso
            exit();
        }else{
            echo "Cadastro não realizado"; // Ponto e vírgula adicionado
        }

     } catch(PDOException $erro) {
        echo "Entre em contato com o suporte: " . $erro->getMessage(); // Adicionado mensagem de erro para debug
     }
?>
