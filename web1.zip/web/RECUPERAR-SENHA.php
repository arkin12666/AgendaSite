<?php
 if(!isset($_SESSION)){
  session_start();
}
?>

<!DOCTYPE html>
<html>
<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
 
  <base href="$FLUTTER_BASE_HREF">

  <meta charset="UTF-8">
  <meta content="IE=Edge" http-equiv="X-UA-Compatible">
  <meta name="description" content="A new Flutter project.">

  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-title" content="agendaweb">
  <link rel="apple-touch-icon" href="icons/Icon-192.png">

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="maxresdefault.jpg"/>

  <title>AGENDA - RECUPERAR SENHA</title>
  <link rel="manifest" href="manifest.json">
  <link rel="stylesheet" href="CSS-LOGIN.css">
</head>
<body>
  
  <div class="container">
    <div class="tela">
    <h1>RECUPERAR SENHA</h1>

    <?php 
    //receber dados do formulário
     $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

     if(!empty ($dados['SendRecupSenha'])) {
        var_dump($dados);

        $querry_recuperar = "SELECT IDUser, nomeUser, emailUser FROM usuario WHERE emailUser =:emailUser LIMIT 1";  
           
       $reult_recuperar = $conexao->prepare($querry_recuperar);
       $result_recuperar->bindParam(':emailUser', $dados['emailUser']);

       $result_recuperar->execute(); 
     }

    ?>

    <!-- CAIXA -->
    <div class="menu">
      <form action="LOGIN-VERIFICAR.php" method="post">
        <div class="TextBoxs">
          <input type="text" name="email" id="email" placeholder="Digite seu Email" required> 
        </div>

        <div class="conteudo">
          <div>
            <button type="submit" name = "SendRecupSenha" value ="Recuperar" class="botoes">RECUPERAR </button>
        </div>
        <h5><a href="LOGIN-PRINCIPAL.php">Voltar</a></h5>
      </form>
    

    </div>
    <!-- CAIXA -->

    </div>
  </div>
  <script src="flutter_bootstrap.js" async></script>
</body>
</html>