<?php
session_start();  // Inicia sessão no topo

// Conexão com o banco (caminho corrigido para subpasta)
require_once("./conexao/conexao.php");  // Caminho para a subpasta 'conexao'

// Filtros de entrada (ajustado para senha)
$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
$senha = $_POST['senha'] ?? '';  // Sem filtro que corrompa a senha
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_SPECIAL_CHARS);

// Verifica se os campos foram preenchidos
if (!$nome || !$senha || !$email) {
    echo "Nome, email e senha são obrigatórios.";
    exit;
}

// Query preparada para buscar o usuário (usando PDO)
$query = "SELECT * FROM usuario WHERE nomeUser = ?";
$stmt = $conexao->prepare($query);
$stmt->bindParam(1, $nome, PDO::PARAM_STR);
$stmt->execute();
$linha = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$linha) {
    echo "Nome não encontrado.";
    exit;
}

// Query preparada para buscar o usuário (usando PDO)
$query_email = "SELECT * FROM usuario WHERE emailUser = ?";
$stmt = $conexao->prepare($query_email);
$stmt->bindParam(1, $email, PDO::PARAM_STR);
$stmt->execute();
$linha = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$linha) {
    echo "Email não encontrado.";
    exit;
}

// Validação de senha usando password_verify
if (password_verify($senha, $linha["senhaUser"])) {
    // Login bem-sucedido: define sessão e redireciona
    $_SESSION['usuario'] = $linha['nomeUser'];
    header("Location: MENU.php");
    exit;
} else {
    echo "Senha incorreta.";
    exit;
}

// Fecha a conexão
$conexao = null;
?>